﻿using loterie_2022.Models.Blog;
using loterie_2022.services;
using loterie_2022.services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace loterie_2022.Controllers
{
    public class BlogController : Controller
    {
        private readonly IBlogService _blogSvc;
        public BlogController(IBlogService svc)
        {
            _blogSvc = svc;
        }

        // GET /blog/create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreateViewModel model)
        {
            //Valider la donnée reçue
            if (ModelState.IsValid == false)
            {
                //renvoyer le meme formulaire avec les données erronées et des messages d'erreur
                return View(model);

                //ou envoyer une response erro404
                //return BadRequest();
            }

            //traitement de la donnée reçue
            //envoie à un service pour stockage en DB
            _blogSvc.CreateBlog(model);

            //redirection ou autre
            return RedirectToAction("index", "home");
        }

        // GET blog/createPost
        public IActionResult CreatePost()
        {

            var model = new CreatePostViewModel()
            {
                BlogId = 1002
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        // POST blog/createPost
        public IActionResult CreatePost(CreatePostViewModel model)
        {
            if (ModelState.IsValid == false)
            {
                return View(model);
            }

            _blogSvc.CreatePost(model);

            return RedirectToAction("index", "home");
        }
    }
}
