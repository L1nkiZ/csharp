﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using loterie_2022.Models;
using DataLayer;
using DataLayer.Model;
using loterie_2022.services.Interfaces;

namespace loterie_2022.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IMaClasse _classe;
    private readonly IHelpersService _helpersService;
    private readonly AppDbContext ctx;

    public HomeController(
        ILogger<HomeController> logger, 
        IMaClasse classe,
        IHelpersService helpersService,
        AppDbContext ctx)
    {
        _logger = logger;
        _classe = classe;
        _helpersService = helpersService;
        this.ctx = ctx;
    }

    //public IActionResult Index(string name, int age)
    //{
    //    name = "Quentin";
    //    age = 23;

    //    var result = new IndexViewModel
    //    {
    //        Age = age,
    //        Name = name,
    //        Greetings = _classe.DisSalut(name),
    //        CurrentDate = _helpersService.GetCurrentDate(),
    //        CurrentTime = _helpersService.GetCurrentTime()
    //    };

    //    return View("index", result);
    //}

    public IActionResult Index()
    {
        //var objBlog = new Blog()
        //{
        //    Name = "My nice blog",
        //    Url = "http://nice.blog/",
        //    LastPost = DateTime.Now
        //};
        //ctx.Blogs.Add(objBlog);
        //ctx.SaveChanges();

        var model = _helpersService.GetData();

        return View("index", model);
    }

    public IActionResult Privacy()
    {
        //var entity = ctx.Blogs.First();
        //entity.LastPost = DateTime.Now;

        //ctx.SaveChanges();

        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        //select * from blogs where id > 5 order by name (seulement la requete)
        var data = ctx.Blogs
            .Where(b => b.Id > 5)
            .OrderBy(b => b.Name)
            .ToList();

        //select * from blogs where id=2 (execute la requete) !! Ici le where s'execute dans la BDD
        var d2 = ctx.Blogs
            .First(b => b.Id == 2);

        //select * from blogs puis je transforme ma data en liste et je fais mon where sur la liste et non sur la BDD
        var blogs = ctx.Blogs
            .ToList()
            .First(b => b.Id == 2);

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
