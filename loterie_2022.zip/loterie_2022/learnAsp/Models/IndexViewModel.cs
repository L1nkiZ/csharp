﻿namespace loterie_2022.Models
{
    public class IndexViewModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Greetings { get; set; }
        public DateTime CurrentDate { get; set; }
        public string CurrentTime { get; set; }
    }
}
