namespace loterie_2022.Models;

public class ErrorViewModel
{
    public string? RequestId { get; set; }

    //public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    //Ci-dessus en "ternaire" et en-dessous de fa�ons classique...

    public bool ShowRequestId
    {
        get
        {
            return !string.IsNullOrEmpty(RequestId);
        }
    }
}
