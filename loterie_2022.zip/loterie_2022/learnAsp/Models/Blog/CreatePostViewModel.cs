﻿namespace loterie_2022.Models.Blog
{
    public class CreatePostViewModel
    {
        public string Title { get; set; }
        public string Content { get; set; }
        public bool Private { get; set; }
        public int BlogId { get; set; }
    }
}
