﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace loterie_2022.Models.Blog
{
    public class CreateViewModel
    {
        [Required(ErrorMessage = "Ce champs est requis !")]
        [MaxLength(35, ErrorMessage = "Votre saisie dépasse 35 charactères !")]
        [DisplayName("Nom du blog")]
        public string Name { get; set; }

        [MaxLength(200, ErrorMessage = "Votre saisie dépasse 200 charactères !")]
        public string? Description { get; set; }

    }
}
