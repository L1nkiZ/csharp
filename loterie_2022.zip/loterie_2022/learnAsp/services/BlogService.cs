﻿using DataLayer;
using DataLayer.Model;
using loterie_2022.Models.Blog;
using loterie_2022.services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace loterie_2022.services
{
    public class BlogService: IBlogService
    {
        private readonly AppDbContext dbContext;
        public BlogService(AppDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public void CreateBlog(CreateViewModel model)
        {
            var objBlog = new Blog()
            {
                Name = model.Name,
                Description = model.Description,
                LastPost = default(DateTime),
            };

            dbContext.Blogs.Add(objBlog);
            dbContext.SaveChanges();

        }

        public void CreatePost(CreatePostViewModel model)
        {
            //Select * from blog
            var blog1 = dbContext.Blogs.ToList();

            //Select * from blog INNER JOIN post ON post.blogId = blog.Id
            var blog2 = dbContext.Blogs.Include(b => b.Posts).ToList();


            var blog = dbContext.Blogs.FirstOrDefault( b => b.Id == model.BlogId );

            if (blog == null)
            {
                //Action en cas d'absence du blog...
                return;
            }

            var post = new Post()
            {
                Blog = blog,
                Title = model.Title,
                Content = model.Content,
                Private = model.Private,
            };

            blog.LastPost = DateTime.Now;

            dbContext.Post.Add(post);
            dbContext.SaveChanges();
        }
    }
}
