﻿using loterie_2022.Models;
using loterie_2022.services.Interfaces;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Xml.Linq;

namespace loterie_2022.services
{
    public class HelpersService : IHelpersService
    {
        private readonly IMaClasse _classe;

        public HelpersService(IMaClasse classe) 
        {
            _classe = classe;
        }
        public DateTime GetCurrentDate()
        {
            return DateTime.Now.Date;
        }

        public string GetCurrentTime()
        {
            return DateTime.Now.ToString("T");
        }

        public IndexViewModel GetData()
        {
            var name = "Quentin";
            var age = 23;

            var result = new IndexViewModel()
            {
                Age = age,
                Name = name,
                Greetings = _classe.DisSalut(name),
                CurrentDate = GetCurrentDate(),
                CurrentTime = GetCurrentTime()
            };

            return result;
        }
    }
}
