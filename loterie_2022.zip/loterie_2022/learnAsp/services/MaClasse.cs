﻿using loterie_2022.services.Interfaces;

namespace loterie_2022.services
{
    public class MaClasse : IMaClasse
    {
        public string DisSalut()
        {
            return "salut toi !";
        }

        public string DisSalut(string nom)
        {
            return "Salut " + nom + " !";
        }
    }
}
