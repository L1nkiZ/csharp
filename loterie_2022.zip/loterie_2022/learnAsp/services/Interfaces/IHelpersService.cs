﻿using loterie_2022.Models;

namespace loterie_2022.services.Interfaces
{
    public interface IHelpersService
    {
        DateTime GetCurrentDate();
        string GetCurrentTime();
        IndexViewModel GetData();
    }
}
