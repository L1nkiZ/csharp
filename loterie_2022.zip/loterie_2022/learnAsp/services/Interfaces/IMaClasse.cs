﻿namespace loterie_2022.services.Interfaces
{
    public interface IMaClasse
    {
        string DisSalut();
        string DisSalut(string nom);
    }
}
