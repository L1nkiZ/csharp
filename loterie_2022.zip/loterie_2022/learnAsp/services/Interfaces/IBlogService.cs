﻿using loterie_2022.Models.Blog;

namespace loterie_2022.services.Interfaces
{
    public interface IBlogService
    {
        void CreateBlog(CreateViewModel model);
        void CreatePost(CreatePostViewModel model);
    }
}
