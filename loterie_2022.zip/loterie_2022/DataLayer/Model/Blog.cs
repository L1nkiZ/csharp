﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DataLayer.Model
{
    public class Blog
    {
        [Key]
        public int Id { get; set; }

        //varchar(200) nullable car ? après string :
        [MaxLength(200)]
        public string? Description { get; set; }

        [MaxLength(35)]
        public string Name { get; set; }

        //Non null
        public DateTime LastPost { get; set; }

        //Cardinalité :
        #region 0-n
        //propriété de navigation
        //navigation property

        public List<Post> Posts { get; set; }

        #endregion
    }
}
